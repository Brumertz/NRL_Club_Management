﻿INSERT INTO [dbo].[Club] ([TeamName], [HomeCity], [CoachName], [Stadium])
VALUES
    ('Panthers', 'Penrith', 'Ivan Cleary', 'BlueBet Stadium'),
    ('Storm', 'Melbourne', 'Craig Bellamy', 'AAMI Park'),
    ('Eels', 'Parramatta', 'Brad Arthur', 'CommBank Stadium'),
    ('Rabbitohs', 'South Sydney', 'Jason Demetriou', 'Accor Stadium'),
    ('Roosters', 'Sydney', 'Trent Robinson', 'Allianz Stadium'),
    ('Sea Eagles', 'Manly', 'Anthony Seibold', '4 Pines Park'),
    ('Dragons', 'St George', 'Ryan Carr', 'WIN Stadium'),
    ('Titans', 'Gold Coast', 'Justin Holbrook', 'Cbus Super Stadium'),
    ('Warriors', 'Auckland', 'Andrew Webster', 'Mt Smart Stadium'),
    ('Cowboys', 'North Queensland', 'Todd Payten', 'Queensland Country Bank Stadium'),
    ('Raiders', 'Canberra', 'Ricky Stuart', 'GIO Stadium'),
    ('Knights', 'Newcastle', 'Adam O’Brien', 'McDonald Jones Stadium'),
    ('Sharks', 'Cronulla', 'Craig Fitzgibbon', 'PointsBet Stadium'),
    ('Wests Tigers', 'Sydney', 'Tim Sheens', 'Leichhardt Oval'),
    ('Broncos', 'Brisbane', 'Kevin Walters', 'Suncorp Stadium'),
    ('Bulldogs', 'Canterbury', 'Cameron Ciraldo', 'Accor Stadium');
